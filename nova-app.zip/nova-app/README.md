# Nova — Chatbot IA Bilingue

## 🚀 Déploiement sur Vercel via GitHub

### Étape 1 — Mettre le code sur GitHub
1. Va sur [github.com](https://github.com) et crée un compte (gratuit)
2. Clique sur **"New repository"** (bouton vert en haut à droite)
3. Nomme-le `nova-chatbot`, laisse tout par défaut, clique **"Create repository"**
4. Sur la page qui s'affiche, clique sur **"uploading an existing file"**
5. Glisse-dépose tous les fichiers du dossier `nova-app` dans la zone
6. Clique **"Commit changes"**

### Étape 2 — Connecter GitHub à Vercel
1. Va sur [vercel.com](https://vercel.com) et connecte-toi
2. Clique **"Add New Project"**
3. Clique **"Import"** à côté de ton repo `nova-chatbot`
4. Vercel détecte automatiquement Next.js — clique **"Deploy"**

### Étape 3 — Ajouter ta clé API Anthropic
1. Dans Vercel, va dans **Settings → Environment Variables**
2. Ajoute une variable :
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** ta clé (disponible sur console.anthropic.com)
3. Clique **Save**, puis **Redeploy**

### Étape 4 — Installer sur ton téléphone
1. Ouvre le lien Vercel sur ton téléphone (ex: `nova-chatbot.vercel.app`)
2. **iPhone:** Appuie sur le bouton Partager → "Sur l'écran d'accueil"
3. **Android:** Menu du navigateur → "Ajouter à l'écran d'accueil"

✅ Nova apparaît comme une vraie app sur ton téléphone !
